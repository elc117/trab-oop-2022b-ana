public class Galinha extends Animal {
  String corDaPlumagem;
  String tipoDeCrista;
  String origem;
  int numeroDeDedos;
  int quantidadeDeFranjas;
}