public class Gato extends Animal {
  String pelagem;
  int comprimento;
  int espessura;
}