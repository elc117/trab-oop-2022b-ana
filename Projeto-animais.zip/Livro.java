public class Livro {
  String nome;

  public Livro(String nome) {
    this.nome = nome;
  }

 /* public Livro() {
    this.nome = nome;
  } */
}