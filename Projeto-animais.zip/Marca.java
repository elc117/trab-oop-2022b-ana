public class Marca {
  String nome;
  String link;

  public Marca() {
    this.nome = nome;
    this.link = link;
  }
}