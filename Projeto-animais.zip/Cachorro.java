public class Cachorro extends Animal {
  String pelagem;
  int porte;
  double peso;
}