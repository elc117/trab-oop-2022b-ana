public class Animal {
  String nome;
  String cor;
  String raca;
  int idade;

  public Animal() {
    this.nome = nome;
    this.cor = cor;
    this.idade = idade;
    this.raca = raca;
  }
}